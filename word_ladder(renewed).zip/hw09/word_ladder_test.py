from word_ladder import WordLadder


# TODO: Write appropriate unit tests


def test_make_ladder():
    # Load a sample dictionary of words for testing
    words_set = {"cat", "bat", "rat", "mat", "hat", "heat", "meat", "mate"}

    # Test Case 1: Short word ladder
    wl1 = WordLadder("cat", "hat", words_set)
    assert wl1.make_ladder() == ["cat", "hat"]

    # Test Case 2: Longer word ladder
    wl2 = WordLadder("cat", "mat", words_set)
    assert wl2.make_ladder() == ["cat", "mat"]  # Shortest path example

    # Test Case 3: No ladder possible
    wl3 = WordLadder("cat", "dog", words_set)
    assert wl3.make_ladder() is None

    # Test Case 4: Same word as start and end
    wl4 = WordLadder("cat", "cat", words_set)
    assert wl4.make_ladder() == ["cat"]

    # Test Case 5: Words of different lengths
    try:
        wl5 = WordLadder("cat", "cater", words_set)
        wl5.make_ladder()
        # This line will not execute because the exception in __init__
    except ValueError as e:
        assert str(e) == "Start and end words must be of the same length."

    # Test Case 6: Complex word ladder with multiple steps
    words_set_complex = {"angel", "anger", "anger", "leger", "lever", "level",
                         "devil"}
    wl6 = WordLadder("angel", "devil", words_set_complex)
    assert wl6.make_ladder() == ["angel", "anger", "leger", "lever", "level", 
                                 "devil"]

    # Test Case 7: Long word ladder (earth -> ocean)
    words_set_long = {
        "earth",
        "barth",
        "barih",
        "baris",
        "batis",
        "bitis",
        "aitis",
        "antis",
        "antas",
        "antal",
        "ontal",
        "octal",
        "octan",
        "ocean",
    }
    wl7 = WordLadder("earth", "ocean", words_set_long)
    assert wl7.make_ladder() == [
        "earth",
        "barth",
        "barih",
        "baris",
        "batis",
        "bitis",
        "aitis",
        "antis",
        "antas",
        "antal",
        "ontal",
        "octal",
        "octan",
        "ocean",
    ]

    print("All tests passed!")


if __name__ == "__main__":
    try:
        test_make_ladder()
    except AssertionError:
        print("Some tests failed")
