import string
from queue import Queue
from stack import Stack


class WordLadder:
    """A class providing functionality to create word ladders"""

    # TODO:
    # Implement whatever functionality is necessary to generate a
    # stack representing the word ladder based on the parameters
    # passed to the constructor.
    def __init__(self, start_word, end_word, words_set):
        """Initialize with start and end words and a set of valid English
        words of the same length."""
        self.start_word = start_word
        self.end_word = end_word
        # Set of valid words with the correct length
        self.words_set = words_set
        if len(self.start_word) != len(self.end_word):
            raise ValueError("Start and end words must be of the same length.")

    def is_valid_word(self, word):
        """Check if the word exists in the English words set."""
        return word in self.words_set

    def make_ladder(self):
        """Generate the shortest word ladder from start_word to end_word."""
        if len(self.start_word) != len(self.end_word):
            return None  # Different lengths, no ladder possible

        # Initialize the queue with a stack containing only the start_word
        queue = Queue()
        initial_stack = Stack()
        initial_stack.push(self.start_word)
        queue.enqueue(initial_stack)

        # Use a set to track visited words to prevent cycles
        visited = set()
        visited.add(self.start_word)

        # Perform a BFS on the queue of stacks
        while not queue.is_empty():
            current_stack = queue.dequeue()
            current_word = current_stack.peek()

            # Generate all one-letter variations of the current word
            for i in range(len(current_word)):
                for letter in string.ascii_lowercase:
                    if letter != current_word[i]:  # Skip the same letter
                        # Create a new word by changing one letter
                        new_word = current_word[:i]
                        + letter
                        + current_word[i + 1:]

                        # If it's a valid word and hasn't been visited
                        if self.is_valid_word(new_word) and new_word\
                           not in visited:
                            # Duplicate the stack and push the new word onto it
                            new_stack = current_stack.copy()
                            new_stack.push(new_word)
                            visited.add(new_word)  # Mark as visited

                            # If we've reached the end word,
                            # return the ladder as a list
                            if new_word == self.end_word:
                                return new_stack.items

                            # Otherwise, enqueue the new stack
                            # to explore further
                            queue.enqueue(new_stack)

        # If no ladder is found
        return None
